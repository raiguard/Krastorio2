data:extend({
  {
    type = "damage-type",
    name = "radioactive",
  },
})

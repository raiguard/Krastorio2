if mods["aai-vehicles-flame-tank"] and data.raw["car"]["vehicle-flame-tank"] then
  data.raw["car"]["vehicle-flame-tank"].equipment_grid = "kr-tank-grid"
end

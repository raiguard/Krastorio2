-- Adding character equipment
require(kr_equipments_prototypes_path .. "equipment-character")
require(kr_equipments_prototypes_path .. "equipment-vehicle")
require(kr_equipments_prototypes_path .. "equipment-universal")

require(kr_data_final_fixes_compatibility_path .. "Pyanodon/pycoalprocessing")
require(kr_data_final_fixes_compatibility_path .. "Pyanodon/pyrawores")
require(kr_data_final_fixes_compatibility_path .. "Pyanodon/pyfusionenergy")
require(kr_data_final_fixes_compatibility_path .. "Pyanodon/pyhightech")

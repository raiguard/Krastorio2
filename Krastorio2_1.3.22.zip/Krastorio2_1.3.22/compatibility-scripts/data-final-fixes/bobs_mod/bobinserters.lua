if mods["bobinserters"] then
  data.raw["custom-input"]["kr-inserter-change-lane"] = nil
end

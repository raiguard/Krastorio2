require(kr_damages_path .. "explosion-damage")
require(kr_damages_path .. "radioactive-damage")

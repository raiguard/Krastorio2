local bobs_mod_patch_folder = "__Krastorio2__/compatibility-scripts/data-final-fixes/bobs_mod/"

require(bobs_mod_patch_folder .. "bobinserters")

if data.raw["string-setting"] and data.raw["string-setting"]["loaders-snap"] then
  table.insert(data.raw["string-setting"]["loaders-snap"].allowed_values, "Krastorio2")
end

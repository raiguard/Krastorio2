local aai_vehicles_path = "compatibility-scripts/data-updates/aai-vehicles/"
require(aai_vehicles_path .. "aai-vehicles-chaingunner")
require(aai_vehicles_path .. "aai-vehicles-flame-tank")
require(aai_vehicles_path .. "aai-vehicles-flame-tumbler")
require(aai_vehicles_path .. "aai-vehicles-hauler")
require(aai_vehicles_path .. "aai-vehicles-laser-tank")
require(aai_vehicles_path .. "aai-vehicles-miner")
require(aai_vehicles_path .. "aai-vehicles-warden")

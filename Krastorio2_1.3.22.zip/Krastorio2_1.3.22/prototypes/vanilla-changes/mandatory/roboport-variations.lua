local variations_util = require(kr_public_lib .. "create-roboport-states")

variations_util.createRoboportVariations("roboport")

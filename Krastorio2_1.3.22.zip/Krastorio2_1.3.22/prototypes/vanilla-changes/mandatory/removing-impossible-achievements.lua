data.raw["finish-the-game-achievement"]["no-time-for-chitchat"] = nil
data.raw["finish-the-game-achievement"]["there-is-no-spoon"] = nil

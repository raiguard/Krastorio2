if mods["FoodIndustry"] then
  if data.raw.item["potato"] then
    data.raw.item["potato"] = nil
  end
end

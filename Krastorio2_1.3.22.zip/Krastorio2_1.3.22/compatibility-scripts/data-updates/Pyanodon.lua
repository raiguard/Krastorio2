require(kr_data_updates_compatibility_path .. "Pyanodon/pycoalprocessing")
require(kr_data_updates_compatibility_path .. "Pyanodon/pyfusionenergy")
require(kr_data_updates_compatibility_path .. "Pyanodon/pyhightech")

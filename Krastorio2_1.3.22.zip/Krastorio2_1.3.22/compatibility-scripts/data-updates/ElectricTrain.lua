if mods["ElectricTrain"] then
  data.raw["locomotive"]["et-electric-locomotive-1"].equipment_grid = "kr-locomotive-grid"
  data.raw["locomotive"]["et-electric-locomotive-2"].equipment_grid = "kr-locomotive-grid"
  data.raw["locomotive"]["et-electric-locomotive-3"].equipment_grid = "kr-locomotive-grid"
  data.raw["cargo-wagon"]["et-cargo-wagon-2"].equipment_grid = "kr-wagons-grid"
  data.raw["cargo-wagon"]["et-cargo-wagon-3"].equipment_grid = "kr-wagons-grid"
  data.raw["fluid-wagon"]["et-fluid-wagon-2"].equipment_grid = "kr-wagons-grid"
  data.raw["fluid-wagon"]["et-fluid-wagon-3"].equipment_grid = "kr-wagons-grid"
end
